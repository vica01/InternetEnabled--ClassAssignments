<?php
// Protect from unauthorized access
defined('_JEXEC') or die;

define('ADMINTOOLS_VERSION', '4.0.2');
define('ADMINTOOLS_DATE', '2016-10-25');
define('ADMINTOOLS_PRO','0');