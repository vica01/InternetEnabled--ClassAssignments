-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2017 at 09:15 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wordpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpresscommentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_wordpresscommentmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpresscomments`
--

CREATE TABLE IF NOT EXISTS `wp_wordpresscomments` (
`comment_ID` bigint(20) unsigned NOT NULL,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `wp_wordpresscomments`
--

INSERT INTO `wp_wordpresscomments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2017-02-01 08:49:52', '2017-02-01 08:49:52', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0),
(2, 49, 'admin', 'emmanuelvitus01@gmail.com', '', '::1', '2017-02-04 23:40:41', '2017-02-04 23:40:41', 'Great Site', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpresslinks`
--

CREATE TABLE IF NOT EXISTS `wp_wordpresslinks` (
`link_id` bigint(20) unsigned NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpressoptions`
--

CREATE TABLE IF NOT EXISTS `wp_wordpressoptions` (
`option_id` bigint(20) unsigned NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=266 ;

--
-- Dumping data for table `wp_wordpressoptions`
--

INSERT INTO `wp_wordpressoptions` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/wordpress/wordpress', 'yes'),
(2, 'home', 'http://localhost/wordpress/wordpress', 'yes'),
(3, 'blogname', 'Valley News Authority', 'yes'),
(4, 'blogdescription', 'The Truth in The Dark.', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'emmanuelvitus01@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=98&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:22:"wp-editor/wpeditor.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:79:"C:\\xampp\\htdocs\\wordpress\\wordpress/wp-content/themes/twentyseventeen/style.css";i:1;s:0:"";}', 'no'),
(40, 'template', 'twentyseventeen', 'yes'),
(41, 'stylesheet', 'twentyseventeen', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:6:{i:1;a:0:{}s:12:"_multiwidget";i:1;i:2;a:2:{s:5:"title";s:7:"Find Us";s:4:"text";s:200:"<p><strong>Address</strong><br />123 Main Street<br />New York, NY 10001</p><p><strong>Hours</strong><br />Monday&mdash;Friday: 9:00AM&ndash;5:00PM<br />Saturday &amp; Sunday: 11:00AM&ndash;3:00PM</p>";}i:3;a:2:{s:5:"title";s:15:"About This Site";s:4:"text";s:85:"This may be a good place to introduce yourself and your site or include some credits.";}i:4;a:3:{s:5:"title";s:7:"Find Us";s:4:"text";s:222:"<p><strong>Address</strong><br />Valley View University<br />Department of Engineering Science</p><p><strong>Hours</strong><br />Monday&mdash;Friday: 9:00AM&ndash;5:00PM<br />Saturday &amp; Sunday: 11:00AM&ndash;3:00PM</p>";s:6:"filter";b:0;}i:5;a:3:{s:5:"title";s:15:"About This Site";s:4:"text";s:172:"Founded by Emmanuel Vitus, \r\nVNA is a Media Corporation developed to present to the people true happenings, around and within  their vicinity.\r\nTruly a media for the people";s:6:"filter";b:0;}}', 'yes'),
(80, 'widget_rss', 'a:3:{i:1;a:0:{}s:12:"_multiwidget";i:1;i:3;a:6:{s:5:"title";s:10:"Live Feeds";s:3:"url";s:57:"https://www.youtube.com/watch?v=D-10C9n74J0&feature=share";s:5:"items";i:10;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '9', 'yes'),
(84, 'page_on_front', '98', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '42', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_wordpressuser_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:4:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;i:3;a:1:{s:5:"title";s:6:"Search";}i:4;a:1:{s:5:"title";s:6:"Search";}}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:1:{i:0;s:8:"search-4";}s:9:"sidebar-1";a:3:{i:0;s:6:"text-2";i:1;s:8:"search-3";i:2;s:6:"text-3";}s:9:"sidebar-2";a:1:{i:0;s:6:"text-4";}s:9:"sidebar-3";a:2:{i:0;s:6:"text-5";i:1;s:5:"rss-3";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:2:{s:12:"_multiwidget";i:1;i:3;a:0:{}}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:5:{i:1486284596;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1486285303;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"e53177ff0cb5087e4d492470cc4519bd";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:91;}}}}i:1486285337;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1486335121;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(105, 'theme_mods_twentyseventeen', 'a:14:{s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:3:{s:6:"social";i:4;s:9:"copyright";i:2;s:3:"top";i:2;}s:7:"panel_1";i:0;s:7:"panel_2";i:9;s:7:"panel_3";i:0;s:7:"panel_4";i:0;s:12:"header_image";s:82:"http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-flare5.jpg";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:17;s:3:"url";s:82:"http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-flare5.jpg";s:13:"thumbnail_url";s:82:"http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-flare5.jpg";s:6:"height";i:1200;s:5:"width";i:2000;}s:12:"header_video";i:0;s:21:"external_header_video";s:57:"https://www.youtube.com/watch?v=D-10C9n74J0&feature=share";s:16:"header_textcolor";s:6:"ffffff";s:11:"custom_logo";i:41;s:11:"colorscheme";s:5:"light";s:15:"colorscheme_hue";i:64;}', 'yes'),
(109, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.7.2.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.7.2.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.7.2-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.7.2-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.7.2";s:7:"version";s:5:"4.7.2";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.7";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1486278105;s:15:"version_checked";s:5:"4.7.2";s:12:"translations";a:0:{}}', 'no'),
(115, '_site_transient_timeout_browser_3724cf524ce46cd3376f6aebb4c04837', '1486543821', 'no'),
(116, '_site_transient_browser_3724cf524ce46cd3376f6aebb4c04837', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"55.0.2883.87";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'no'),
(117, 'can_compress_scripts', '1', 'no'),
(136, 'current_theme', 'Twenty Seventeen', 'yes'),
(137, 'theme_mods_ValleyNewsAuthority', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1486168800;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(138, 'theme_switched', '', 'yes'),
(146, '_transient_timeout_plugin_slugs', '1486366625', 'no'),
(147, '_transient_plugin_slugs', 'a:3:{i:0;s:19:"akismet/akismet.php";i:1;s:9:"hello.php";i:2;s:22:"wp-editor/wpeditor.php";}', 'no'),
(153, 'recently_activated', 'a:0:{}', 'yes'),
(156, '_site_transient_timeout_wporg_theme_feature_list', '1486179372', 'no'),
(157, '_site_transient_wporg_theme_feature_list', 'a:0:{}', 'no'),
(161, 'theme_mods_newsmag', 'a:4:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:2:{s:6:"social";i:2;s:9:"copyright";i:2;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1486234592;s:4:"data";a:8:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:7:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";i:6;s:23:"newsmag_slider_widget-2";}s:15:"homepage-slider";a:0:{}s:12:"content-area";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}}}}', 'yes'),
(162, 'widget_newsmag_slider_widget', 'a:2:{i:2;a:2:{s:5:"title";s:20:"Today’s hot topics";s:16:"newsmag_category";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(163, 'widget_newsmag-popular-posts-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(164, 'widget_newsmag_widget_posts_column', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(165, 'widget_newsmag_widget_posts_grid', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(166, 'widget_newsmag_widget_posts_list_horizontal', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(167, 'widget_newsmag_widget_posts_list_vertical', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(168, '_site_transient_update_themes', 'O:8:"stdClass":2:{s:12:"last_checked";i:1486278105;s:7:"checked";a:5:{s:19:"ValleyNewsAuthority";s:3:"1.0";s:7:"newsmag";s:5:"2.2.0";s:13:"twentyfifteen";s:3:"1.7";s:15:"twentyseventeen";s:3:"1.1";s:13:"twentysixteen";s:3:"1.3";}}', 'no'),
(176, 'category_children', 'a:0:{}', 'yes'),
(178, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:1:{i:0;i:2;}}', 'yes'),
(213, '_transient_timeout_dash_88ae138922fe95674369b1cb3d215a2b', '1486291736', 'no'),
(214, '_transient_dash_88ae138922fe95674369b1cb3d215a2b', '<div class="rss-widget"><p><strong>RSS Error:</strong> WP HTTP Error: cURL error 6: Could not resolve host: wordpress.org</p></div><div class="rss-widget"><p><strong>RSS Error:</strong> WP HTTP Error: cURL error 6: Could not resolve host: planet.wordpress.org</p></div><div class="rss-widget"><ul></ul></div>', 'no'),
(238, '_site_transient_update_plugins', 'O:8:"stdClass":1:{s:12:"last_checked";i:1486280225;}', 'no'),
(239, 'wpe_settings', '', 'yes'),
(262, '_site_transient_timeout_theme_roots', '1486284234', 'no'),
(263, '_site_transient_theme_roots', 'a:5:{s:19:"ValleyNewsAuthority";s:7:"/themes";s:7:"newsmag";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:15:"twentyseventeen";s:7:"/themes";s:13:"twentysixteen";s:7:"/themes";}', 'no'),
(265, '_transient_is_multi_author', '0', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpresspostmeta`
--

CREATE TABLE IF NOT EXISTS `wp_wordpresspostmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=343 ;

--
-- Dumping data for table `wp_wordpresspostmeta`
--

INSERT INTO `wp_wordpresspostmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(4, 1, '_wp_trash_meta_status', 'publish'),
(5, 1, '_wp_trash_meta_time', '1486233448'),
(6, 1, '_wp_desired_post_slug', 'hello-world'),
(7, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(8, 6, '_wp_attached_file', '2017/02/espresso.jpg'),
(9, 6, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1200;s:4:"file";s:20:"2017/02/espresso.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"espresso-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"espresso-300x180.jpg";s:5:"width";i:300;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"espresso-768x461.jpg";s:5:"width";i:768;s:6:"height";i:461;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"espresso-1024x614.jpg";s:5:"width";i:1024;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:20:"espresso-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(10, 6, '_starter_content_theme', 'twentyseventeen'),
(12, 7, '_wp_attached_file', '2017/02/sandwich.jpg'),
(13, 7, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1200;s:4:"file";s:20:"2017/02/sandwich.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"sandwich-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"sandwich-300x180.jpg";s:5:"width";i:300;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"sandwich-768x461.jpg";s:5:"width";i:768;s:6:"height";i:461;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"sandwich-1024x614.jpg";s:5:"width";i:1024;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:20:"sandwich-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(14, 7, '_starter_content_theme', 'twentyseventeen'),
(16, 8, '_wp_attached_file', '2017/02/coffee.jpg'),
(17, 8, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1200;s:4:"file";s:18:"2017/02/coffee.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"coffee-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"coffee-300x180.jpg";s:5:"width";i:300;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"coffee-768x461.jpg";s:5:"width";i:768;s:6:"height";i:461;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"coffee-1024x614.jpg";s:5:"width";i:1024;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"coffee-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(18, 8, '_starter_content_theme', 'twentyseventeen'),
(27, 13, '_thumbnail_id', '6'),
(29, 15, '_wp_attached_file', '2017/02/20170204113412.mp4'),
(30, 15, '_wp_attachment_metadata', 'a:9:{s:8:"filesize";i:807612;s:9:"mime_type";s:15:"video/quicktime";s:6:"length";i:13;s:16:"length_formatted";s:4:"0:13";s:5:"width";i:432;s:6:"height";i:240;s:10:"fileformat";s:3:"mp4";s:10:"dataformat";s:5:"mpeg4";s:5:"audio";a:7:{s:10:"dataformat";s:3:"mp4";s:5:"codec";s:19:"ISO/IEC 14496-3 AAC";s:11:"sample_rate";d:22050;s:8:"channels";i:2;s:15:"bits_per_sample";i:16;s:8:"lossless";b:0;s:11:"channelmode";s:6:"stereo";}}'),
(31, 16, '_wp_attached_file', '2017/02/flare5.jpg'),
(32, 16, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:600;s:4:"file";s:18:"2017/02/flare5.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"flare5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"flare5-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:18:"flare5-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(33, 17, '_wp_attached_file', '2017/02/cropped-flare5.jpg'),
(34, 17, '_wp_attachment_context', 'custom-header'),
(35, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1200;s:4:"file";s:26:"2017/02/cropped-flare5.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"cropped-flare5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"cropped-flare5-300x180.jpg";s:5:"width";i:300;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:26:"cropped-flare5-768x461.jpg";s:5:"width";i:768;s:6:"height";i:461;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"cropped-flare5-1024x614.jpg";s:5:"width";i:1024;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:26:"cropped-flare5-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(36, 17, '_wp_attachment_custom_header_last_used_twentyseventeen', '1486238552'),
(37, 17, '_wp_attachment_is_custom_header', 'twentyseventeen'),
(38, 18, '_wp_attached_file', '2017/02/VI.png'),
(39, 18, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:620;s:6:"height";i:620;s:4:"file";s:14:"2017/02/VI.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:14:"VI-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:14:"VI-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:14:"VI-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(40, 19, '_wp_attached_file', '2017/02/cropped-VI.png'),
(41, 19, '_wp_attachment_context', 'custom-logo'),
(42, 19, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:250;s:6:"height";i:250;s:4:"file";s:22:"2017/02/cropped-VI.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"cropped-VI-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:22:"cropped-VI-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(43, 20, '_menu_item_type', 'post_type'),
(44, 20, '_menu_item_menu_item_parent', '0'),
(45, 20, '_menu_item_object_id', '9'),
(46, 20, '_menu_item_object', 'page'),
(47, 20, '_menu_item_target', ''),
(48, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(49, 20, '_menu_item_xfn', ''),
(50, 20, '_menu_item_url', ''),
(51, 22, '_menu_item_type', 'post_type'),
(52, 22, '_menu_item_menu_item_parent', '0'),
(53, 22, '_menu_item_object_id', '10'),
(54, 22, '_menu_item_object', 'page'),
(55, 22, '_menu_item_target', ''),
(56, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(57, 22, '_menu_item_xfn', ''),
(58, 22, '_menu_item_url', ''),
(59, 24, '_menu_item_type', 'post_type'),
(60, 24, '_menu_item_menu_item_parent', '0'),
(61, 24, '_menu_item_object_id', '11'),
(62, 24, '_menu_item_object', 'page'),
(63, 24, '_menu_item_target', ''),
(64, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(65, 24, '_menu_item_xfn', ''),
(66, 24, '_menu_item_url', ''),
(67, 26, '_menu_item_type', 'post_type'),
(68, 26, '_menu_item_menu_item_parent', '0'),
(69, 26, '_menu_item_object_id', '12'),
(70, 26, '_menu_item_object', 'page'),
(71, 26, '_menu_item_target', ''),
(72, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(73, 26, '_menu_item_xfn', ''),
(74, 26, '_menu_item_url', ''),
(115, 34, '_menu_item_type', 'custom'),
(116, 34, '_menu_item_menu_item_parent', '0'),
(117, 34, '_menu_item_object_id', '34'),
(118, 34, '_menu_item_object', 'custom'),
(119, 34, '_menu_item_target', ''),
(120, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(121, 34, '_menu_item_xfn', ''),
(122, 34, '_menu_item_url', 'https://www.yelp.com'),
(123, 35, '_menu_item_type', 'custom'),
(124, 35, '_menu_item_menu_item_parent', '0'),
(125, 35, '_menu_item_object_id', '35'),
(126, 35, '_menu_item_object', 'custom'),
(127, 35, '_menu_item_target', ''),
(128, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(129, 35, '_menu_item_xfn', ''),
(130, 35, '_menu_item_url', 'https://www.facebook.com/wordpress'),
(131, 36, '_menu_item_type', 'custom'),
(132, 36, '_menu_item_menu_item_parent', '0'),
(133, 36, '_menu_item_object_id', '36'),
(134, 36, '_menu_item_object', 'custom'),
(135, 36, '_menu_item_target', ''),
(136, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(137, 36, '_menu_item_xfn', ''),
(138, 36, '_menu_item_url', 'https://twitter.com/wordpress'),
(139, 37, '_menu_item_type', 'custom'),
(140, 37, '_menu_item_menu_item_parent', '0'),
(141, 37, '_menu_item_object_id', '37'),
(142, 37, '_menu_item_object', 'custom'),
(143, 37, '_menu_item_target', ''),
(144, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(145, 37, '_menu_item_xfn', ''),
(146, 37, '_menu_item_url', 'https://www.instagram.com/explore/tags/wordcamp/'),
(147, 38, '_menu_item_type', 'custom'),
(148, 38, '_menu_item_menu_item_parent', '0'),
(149, 38, '_menu_item_object_id', '38'),
(150, 38, '_menu_item_object', 'custom'),
(151, 38, '_menu_item_target', ''),
(152, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(153, 38, '_menu_item_xfn', ''),
(154, 38, '_menu_item_url', 'mailto:wordpress@example.com'),
(155, 14, '_wp_trash_meta_status', 'publish'),
(156, 14, '_wp_trash_meta_time', '1486238552'),
(157, 40, '_wp_attached_file', '2017/02/VIT.png'),
(158, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:15:"2017/02/VIT.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"VIT-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:15:"VIT-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:15:"VIT-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:17:"VIT-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:30:"twentyseventeen-featured-image";a:4:{s:4:"file";s:17:"VIT-1200x1200.png";s:5:"width";i:1200;s:6:"height";i:1200;s:9:"mime-type";s:9:"image/png";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:15:"VIT-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(159, 41, '_wp_attached_file', '2017/02/cropped-VIT.png'),
(160, 41, '_wp_attachment_context', 'custom-logo'),
(161, 41, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:250;s:6:"height";i:250;s:4:"file";s:23:"2017/02/cropped-VIT.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"cropped-VIT-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:23:"cropped-VIT-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(162, 42, '_wp_attached_file', '2017/02/cropped-VIT-1.png'),
(163, 42, '_wp_attachment_context', 'site-icon'),
(164, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:25:"2017/02/cropped-VIT-1.png";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"cropped-VIT-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"cropped-VIT-1-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:25:"cropped-VIT-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-270";a:4:{s:4:"file";s:25:"cropped-VIT-1-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-192";a:4:{s:4:"file";s:25:"cropped-VIT-1-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";}s:13:"site_icon-180";a:4:{s:4:"file";s:25:"cropped-VIT-1-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"site_icon-32";a:4:{s:4:"file";s:23:"cropped-VIT-1-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(165, 39, '_wp_trash_meta_status', 'publish'),
(166, 39, '_wp_trash_meta_time', '1486238796'),
(167, 43, '_wp_trash_meta_status', 'publish'),
(168, 43, '_wp_trash_meta_time', '1486238863'),
(169, 44, '_wp_trash_meta_status', 'publish'),
(170, 44, '_wp_trash_meta_time', '1486238892'),
(171, 45, '_wp_trash_meta_status', 'publish'),
(172, 45, '_wp_trash_meta_time', '1486238950'),
(235, 66, '_menu_item_type', 'post_type'),
(236, 66, '_menu_item_menu_item_parent', '0'),
(237, 66, '_menu_item_object_id', '51'),
(238, 66, '_menu_item_object', 'page'),
(239, 66, '_menu_item_target', ''),
(240, 66, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(241, 66, '_menu_item_xfn', ''),
(242, 66, '_menu_item_url', ''),
(251, 46, '_wp_trash_meta_status', 'publish'),
(252, 46, '_wp_trash_meta_time', '1486239464'),
(253, 68, '_wp_trash_meta_status', 'publish'),
(254, 68, '_wp_trash_meta_time', '1486239497'),
(255, 70, '_wp_trash_meta_status', 'publish'),
(256, 70, '_wp_trash_meta_time', '1486239864'),
(257, 10, '_edit_lock', '1486281903:1'),
(260, 10, '_edit_last', '1'),
(261, 71, '_wp_trash_meta_status', 'publish'),
(262, 71, '_wp_trash_meta_time', '1486240964'),
(263, 75, '_wp_trash_meta_status', 'publish'),
(264, 75, '_wp_trash_meta_time', '1486241175'),
(265, 76, '_wp_trash_meta_status', 'publish'),
(266, 76, '_wp_trash_meta_time', '1486241441'),
(267, 50, '_edit_lock', '1486269024:1'),
(268, 12, '_edit_lock', '1486282241:1'),
(269, 12, '_edit_last', '1'),
(270, 78, '_edit_last', '1'),
(271, 78, '_edit_lock', '1486276394:1'),
(272, 15, '_thumbnail_id', '79'),
(273, 79, '_wp_attached_file', '2017/02/vvvvv.png'),
(274, 79, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:17:"2017/02/vvvvv.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"vvvvv-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"vvvvv-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:17:"vvvvv-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:19:"vvvvv-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}s:30:"twentyseventeen-featured-image";a:4:{s:4:"file";s:19:"vvvvv-1200x1200.png";s:5:"width";i:1200;s:6:"height";i:1200;s:9:"mime-type";s:9:"image/png";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:17:"vvvvv-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(277, 78, 'enclosure', 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4\n807612\nvideo/mp4\n'),
(278, 11, '_edit_lock', '1486281882:1'),
(279, 11, '_edit_last', '1'),
(280, 15, '_edit_lock', '1486251053:1'),
(281, 9, '_edit_lock', '1486280758:1'),
(282, 9, 'Music', 'All about Music'),
(283, 9, 'Movies', 'All about Movies'),
(284, 9, '_edit_last', '1'),
(285, 49, '_edit_lock', '1486282013:1'),
(286, 49, 'Music', 'All about music'),
(287, 49, 'Movies', 'All about movies'),
(288, 49, '_edit_last', '1'),
(289, 52, '_edit_lock', '1486268070:1'),
(290, 52, 'Movies', 'All About Movies'),
(291, 52, 'Music', 'All about Music'),
(292, 52, '_edit_last', '1'),
(293, 87, '_wp_attached_file', '2017/02/IMG_20170203_111924_036.jpg'),
(294, 87, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2080;s:6:"height";i:1560;s:4:"file";s:35:"2017/02/IMG_20170203_111924_036.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:35:"IMG_20170203_111924_036-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:35:"IMG_20170203_111924_036-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:35:"IMG_20170203_111924_036-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:36:"IMG_20170203_111924_036-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:30:"twentyseventeen-featured-image";a:4:{s:4:"file";s:37:"IMG_20170203_111924_036-2000x1200.jpg";s:5:"width";i:2000;s:6:"height";i:1200;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:35:"IMG_20170203_111924_036-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"2.2";s:6:"credit";s:0:"";s:6:"camera";s:18:"Infinix NOTE 3 Pro";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1486063999";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"3.5";s:3:"iso";s:3:"355";s:13:"shutter_speed";s:8:"0.060003";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(295, 88, '_wp_attached_file', '2017/02/IMG_20170203_111924_036-1.jpg'),
(296, 88, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2080;s:6:"height";i:1560;s:4:"file";s:37:"2017/02/IMG_20170203_111924_036-1.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:37:"IMG_20170203_111924_036-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:37:"IMG_20170203_111924_036-1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:37:"IMG_20170203_111924_036-1-768x576.jpg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:38:"IMG_20170203_111924_036-1-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:30:"twentyseventeen-featured-image";a:4:{s:4:"file";s:39:"IMG_20170203_111924_036-1-2000x1200.jpg";s:5:"width";i:2000;s:6:"height";i:1200;s:9:"mime-type";s:10:"image/jpeg";}s:32:"twentyseventeen-thumbnail-avatar";a:4:{s:4:"file";s:37:"IMG_20170203_111924_036-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"2.2";s:6:"credit";s:0:"";s:6:"camera";s:18:"Infinix NOTE 3 Pro";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1486063999";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"3.5";s:3:"iso";s:3:"355";s:13:"shutter_speed";s:8:"0.060003";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(297, 52, '_wp_trash_meta_status', 'publish'),
(298, 52, '_wp_trash_meta_time', '1486269183'),
(299, 52, '_wp_desired_post_slug', 'entertainment-2'),
(302, 94, '_menu_item_type', 'post_type'),
(303, 94, '_menu_item_menu_item_parent', '0'),
(304, 94, '_menu_item_object_id', '49'),
(305, 94, '_menu_item_object', 'page'),
(306, 94, '_menu_item_target', ''),
(307, 94, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(308, 94, '_menu_item_xfn', ''),
(309, 94, '_menu_item_url', ''),
(310, 93, '_wp_trash_meta_status', 'publish'),
(311, 93, '_wp_trash_meta_time', '1486280524'),
(312, 95, '_wp_trash_meta_status', 'publish'),
(313, 95, '_wp_trash_meta_time', '1486280612'),
(332, 96, '_wp_trash_meta_status', 'publish'),
(333, 96, '_wp_trash_meta_time', '1486281367'),
(334, 98, '_edit_lock', '1486281779:1'),
(335, 98, '_edit_last', '1'),
(336, 107, '_wp_trash_meta_status', 'publish'),
(337, 107, '_wp_trash_meta_time', '1486281604'),
(338, 2, '_edit_lock', '1486281634:1'),
(339, 51, '_edit_lock', '1486282305:1'),
(340, 51, '_edit_last', '1'),
(341, 117, '_wp_trash_meta_status', 'publish'),
(342, 117, '_wp_trash_meta_time', '1486282495');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpressposts`
--

CREATE TABLE IF NOT EXISTS `wp_wordpressposts` (
`ID` bigint(20) unsigned NOT NULL,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=118 ;

--
-- Dumping data for table `wp_wordpressposts`
--

INSERT INTO `wp_wordpressposts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-02-01 08:49:52', '2017-02-01 08:49:52', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2017-02-04 18:37:28', '2017-02-04 18:37:28', '', 0, 'http://localhost/wordpress/wordpress/?p=1', 0, 'post', '', 1),
(2, 1, '2017-02-01 08:49:52', '2017-02-01 08:49:52', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/wordpress/wordpress/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2017-02-01 08:49:52', '2017-02-01 08:49:52', '', 0, 'http://localhost/wordpress/wordpress/?page_id=2', 0, 'page', '', 0),
(3, 1, '2017-02-01 08:50:21', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-02-01 08:50:21', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/wordpress/?p=3', 0, 'post', '', 0),
(5, 1, '2017-02-04 18:37:28', '2017-02-04 18:37:28', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2017-02-04 18:37:28', '2017-02-04 18:37:28', '', 1, 'http://localhost/wordpress/wordpress/2017/02/04/1-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2017-02-04 20:02:23', '2017-02-04 20:02:23', '', 'Espresso', '', 'inherit', 'open', 'closed', '', 'espresso', '', '', '2017-02-04 20:02:23', '2017-02-04 20:02:23', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/espresso.jpg', 0, 'attachment', 'image/jpeg', 0),
(7, 1, '2017-02-04 20:02:23', '2017-02-04 20:02:23', '', 'Sandwich', '', 'inherit', 'open', 'closed', '', 'sandwich', '', '', '2017-02-04 20:02:23', '2017-02-04 20:02:23', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/sandwich.jpg', 0, 'attachment', 'image/jpeg', 0),
(8, 1, '2017-02-04 20:02:23', '2017-02-04 20:02:23', '', 'Coffee', '', 'inherit', 'open', 'closed', '', 'coffee', '', '', '2017-02-04 20:02:23', '2017-02-04 20:02:23', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/coffee.jpg', 0, 'attachment', 'image/jpeg', 0),
(9, 1, '2017-02-04 20:02:23', '2017-02-04 20:02:23', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-02-04 23:39:06', '2017-02-04 23:39:06', '', 49, 'http://localhost/wordpress/wordpress/?page_id=9', 0, 'page', '', 0),
(10, 1, '2017-02-04 20:02:24', '2017-02-04 20:02:24', '[video poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4"][/video]\r\n\r\nWelcome to VNA news site....... Receive live updates here.', 'News', '', 'publish', 'open', 'closed', '', 'news', '', '', '2017-02-05 08:05:01', '2017-02-05 08:05:01', '', 0, 'http://localhost/wordpress/wordpress/?page_id=10', 0, 'page', '', 0),
(11, 1, '2017-02-04 20:02:24', '2017-02-04 20:02:24', 'CONTACT US ON +233579237950\r\n\r\n&nbsp;', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2017-02-05 08:07:00', '2017-02-05 08:07:00', '', 0, 'http://localhost/wordpress/wordpress/?page_id=11', 0, 'page', '', 0),
(12, 1, '2017-02-04 20:02:25', '2017-02-04 20:02:25', '<h3>Stay Tuned for updated list of Today''s Politics.....</h3>', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2017-02-05 08:12:58', '2017-02-05 08:12:58', '', 0, 'http://localhost/wordpress/wordpress/?page_id=12', 0, 'page', '', 0),
(13, 1, '2017-02-04 20:02:26', '2017-02-04 20:02:26', 'This is an example of a homepage section. Homepage sections can be any page other than the homepage itself, including the page that shows your latest blog posts.', 'A homepage section', '', 'publish', 'closed', 'closed', '', 'a-homepage-section', '', '', '2017-02-04 20:02:26', '2017-02-04 20:02:26', '', 0, 'http://localhost/wordpress/wordpress/?page_id=13', 0, 'page', '', 0),
(14, 1, '2017-02-04 20:02:22', '2017-02-04 20:02:22', '{\n    "widget_text[2]": {\n        "starter_content": true,\n        "value": {\n            "encoded_serialized_instance": "YToyOntzOjU6InRpdGxlIjtzOjc6IkZpbmQgVXMiO3M6NDoidGV4dCI7czoyMDA6IjxwPjxzdHJvbmc+QWRkcmVzczwvc3Ryb25nPjxiciAvPjEyMyBNYWluIFN0cmVldDxiciAvPk5ldyBZb3JrLCBOWSAxMDAwMTwvcD48cD48c3Ryb25nPkhvdXJzPC9zdHJvbmc+PGJyIC8+TW9uZGF5Jm1kYXNoO0ZyaWRheTogOTowMEFNJm5kYXNoOzU6MDBQTTxiciAvPlNhdHVyZGF5ICZhbXA7IFN1bmRheTogMTE6MDBBTSZuZGFzaDszOjAwUE08L3A+Ijt9",\n            "title": "Find Us",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "caf60f10607521596803a7a6c61678d8"\n        },\n        "type": "option",\n        "user_id": 1\n    },\n    "widget_search[3]": {\n        "starter_content": true,\n        "value": {\n            "encoded_serialized_instance": "YToxOntzOjU6InRpdGxlIjtzOjY6IlNlYXJjaCI7fQ==",\n            "title": "Search",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "1b2997ef973eb92e5fd8babfdb4207b8"\n        },\n        "type": "option",\n        "user_id": 1\n    },\n    "widget_text[3]": {\n        "starter_content": true,\n        "value": {\n            "encoded_serialized_instance": "YToyOntzOjU6InRpdGxlIjtzOjE1OiJBYm91dCBUaGlzIFNpdGUiO3M6NDoidGV4dCI7czo4NToiVGhpcyBtYXkgYmUgYSBnb29kIHBsYWNlIHRvIGludHJvZHVjZSB5b3Vyc2VsZiBhbmQgeW91ciBzaXRlIG9yIGluY2x1ZGUgc29tZSBjcmVkaXRzLiI7fQ==",\n            "title": "About This Site",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "d1952e9691b04ef5e435560d00ea6820"\n        },\n        "type": "option",\n        "user_id": 1\n    },\n    "sidebars_widgets[sidebar-1]": {\n        "starter_content": true,\n        "value": [\n            "text-2",\n            "search-3",\n            "text-3"\n        ],\n        "type": "option",\n        "user_id": 1\n    },\n    "widget_text[4]": {\n        "starter_content": true,\n        "value": {\n            "encoded_serialized_instance": "YToyOntzOjU6InRpdGxlIjtzOjc6IkZpbmQgVXMiO3M6NDoidGV4dCI7czoyMDA6IjxwPjxzdHJvbmc+QWRkcmVzczwvc3Ryb25nPjxiciAvPjEyMyBNYWluIFN0cmVldDxiciAvPk5ldyBZb3JrLCBOWSAxMDAwMTwvcD48cD48c3Ryb25nPkhvdXJzPC9zdHJvbmc+PGJyIC8+TW9uZGF5Jm1kYXNoO0ZyaWRheTogOTowMEFNJm5kYXNoOzU6MDBQTTxiciAvPlNhdHVyZGF5ICZhbXA7IFN1bmRheTogMTE6MDBBTSZuZGFzaDszOjAwUE08L3A+Ijt9",\n            "title": "Find Us",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "caf60f10607521596803a7a6c61678d8"\n        },\n        "type": "option",\n        "user_id": 1\n    },\n    "sidebars_widgets[sidebar-2]": {\n        "starter_content": true,\n        "value": [\n            "text-4"\n        ],\n        "type": "option",\n        "user_id": 1\n    },\n    "widget_text[5]": {\n        "starter_content": true,\n        "value": {\n            "encoded_serialized_instance": "YToyOntzOjU6InRpdGxlIjtzOjE1OiJBYm91dCBUaGlzIFNpdGUiO3M6NDoidGV4dCI7czo4NToiVGhpcyBtYXkgYmUgYSBnb29kIHBsYWNlIHRvIGludHJvZHVjZSB5b3Vyc2VsZiBhbmQgeW91ciBzaXRlIG9yIGluY2x1ZGUgc29tZSBjcmVkaXRzLiI7fQ==",\n            "title": "About This Site",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "d1952e9691b04ef5e435560d00ea6820"\n        },\n        "type": "option",\n        "user_id": 1\n    },\n    "widget_search[4]": {\n        "starter_content": true,\n        "value": {\n            "encoded_serialized_instance": "YToxOntzOjU6InRpdGxlIjtzOjY6IlNlYXJjaCI7fQ==",\n            "title": "Search",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "1b2997ef973eb92e5fd8babfdb4207b8"\n        },\n        "type": "option",\n        "user_id": 1\n    },\n    "sidebars_widgets[sidebar-3]": {\n        "starter_content": true,\n        "value": [\n            "text-5",\n            "search-4"\n        ],\n        "type": "option",\n        "user_id": 1\n    },\n    "nav_menus_created_posts": {\n        "starter_content": true,\n        "value": [\n            6,\n            7,\n            8,\n            9,\n            10,\n            11,\n            12,\n            13\n        ],\n        "type": "option",\n        "user_id": 1\n    },\n    "nav_menu[-1]": {\n        "value": {\n            "name": "Top Menu",\n            "description": "",\n            "parent": 0,\n            "auto_add": false\n        },\n        "type": "nav_menu",\n        "user_id": 1\n    },\n    "nav_menu_item[-1]": {\n        "value": {\n            "object_id": 0,\n            "object": "",\n            "menu_item_parent": 0,\n            "position": 0,\n            "type": "custom",\n            "title": "Home",\n            "url": "http://localhost/wordpress/wordpress",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "",\n            "nav_menu_term_id": -1,\n            "_invalid": false,\n            "type_label": "Custom Link"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-2]": {\n        "value": {\n            "object_id": 10,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 1,\n            "type": "post_type",\n            "title": "About",\n            "url": "",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "About",\n            "nav_menu_term_id": -1,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-3]": {\n        "value": {\n            "object_id": 12,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 2,\n            "type": "post_type",\n            "title": "Blog",\n            "url": "",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "Blog",\n            "nav_menu_term_id": -1,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-4]": {\n        "value": {\n            "object_id": 11,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 3,\n            "type": "post_type",\n            "title": "Contact",\n            "url": "",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "Contact",\n            "nav_menu_term_id": -1,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "twentyseventeen::nav_menu_locations[top]": {\n        "starter_content": true,\n        "value": -1,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "nav_menu[-5]": {\n        "value": {\n            "name": "Social Links Menu",\n            "description": "",\n            "parent": 0,\n            "auto_add": false\n        },\n        "type": "nav_menu",\n        "user_id": 1\n    },\n    "nav_menu_item[-5]": {\n        "value": {\n            "object_id": 0,\n            "object": "",\n            "menu_item_parent": 0,\n            "position": 0,\n            "type": "custom",\n            "title": "Yelp",\n            "url": "https://www.yelp.com",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "",\n            "nav_menu_term_id": -5,\n            "_invalid": false,\n            "type_label": "Custom Link"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-6]": {\n        "value": {\n            "object_id": 0,\n            "object": "",\n            "menu_item_parent": 0,\n            "position": 1,\n            "type": "custom",\n            "title": "Facebook",\n            "url": "https://www.facebook.com/wordpress",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "",\n            "nav_menu_term_id": -5,\n            "_invalid": false,\n            "type_label": "Custom Link"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-7]": {\n        "value": {\n            "object_id": 0,\n            "object": "",\n            "menu_item_parent": 0,\n            "position": 2,\n            "type": "custom",\n            "title": "Twitter",\n            "url": "https://twitter.com/wordpress",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "",\n            "nav_menu_term_id": -5,\n            "_invalid": false,\n            "type_label": "Custom Link"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-8]": {\n        "value": {\n            "object_id": 0,\n            "object": "",\n            "menu_item_parent": 0,\n            "position": 3,\n            "type": "custom",\n            "title": "Instagram",\n            "url": "https://www.instagram.com/explore/tags/wordcamp/",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "",\n            "nav_menu_term_id": -5,\n            "_invalid": false,\n            "type_label": "Custom Link"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-9]": {\n        "value": {\n            "object_id": 0,\n            "object": "",\n            "menu_item_parent": 0,\n            "position": 4,\n            "type": "custom",\n            "title": "Email",\n            "url": "mailto:wordpress@example.com",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "",\n            "nav_menu_term_id": -5,\n            "_invalid": false,\n            "type_label": "Custom Link"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "twentyseventeen::nav_menu_locations[social]": {\n        "starter_content": true,\n        "value": -5,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "show_on_front": {\n        "starter_content": true,\n        "value": "page",\n        "type": "option",\n        "user_id": 1\n    },\n    "page_on_front": {\n        "starter_content": true,\n        "value": 9,\n        "type": "option",\n        "user_id": 1\n    },\n    "page_for_posts": {\n        "starter_content": true,\n        "value": 12,\n        "type": "option",\n        "user_id": 1\n    },\n    "twentyseventeen::panel_1": {\n        "starter_content": true,\n        "value": 13,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::panel_2": {\n        "starter_content": true,\n        "value": 10,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::panel_3": {\n        "starter_content": true,\n        "value": 12,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::panel_4": {\n        "starter_content": true,\n        "value": 11,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::header_image": {\n        "value": "http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-flare5.jpg",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::header_image_data": {\n        "value": {\n            "url": "http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-flare5.jpg",\n            "thumbnail_url": "http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-flare5.jpg",\n            "timestamp": 1486237212375,\n            "attachment_id": 17,\n            "width": 2000,\n            "height": 1200\n        },\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::header_video": {\n        "value": "",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::external_header_video": {\n        "value": "https://www.youtube.com/watch?v=D-10C9n74J0&feature=share",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "blogdescription": {\n        "value": "The Truth in The Dark.",\n        "type": "option",\n        "user_id": 1\n    },\n    "twentyseventeen::header_textcolor": {\n        "value": "",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::custom_logo": {\n        "value": 19,\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '56d6c16d-5b49-4694-b3d2-b08dbe2dd415', '', '', '2017-02-04 20:02:22', '2017-02-04 20:02:22', '', 0, 'http://localhost/wordpress/wordpress/?p=14', 0, 'customize_changeset', '', 0),
(15, 1, '2017-02-04 19:35:46', '2017-02-04 19:35:46', 'oiasljk', '20170204113412', 'ho', 'inherit', 'open', 'closed', '', '20170204113412', '', '', '2017-02-04 22:54:14', '2017-02-04 22:54:14', '', 78, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4', 0, 'attachment', 'video/mp4', 0),
(16, 1, '2017-02-04 19:40:03', '2017-02-04 19:40:03', '', 'flare5', '', 'inherit', 'open', 'closed', '', 'flare5', '', '', '2017-02-04 19:40:03', '2017-02-04 19:40:03', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/flare5.jpg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2017-02-04 19:40:10', '2017-02-04 19:40:10', '', 'cropped-flare5.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-flare5-jpg', '', '', '2017-02-04 19:40:10', '2017-02-04 19:40:10', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-flare5.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2017-02-04 20:01:24', '2017-02-04 20:01:24', '', 'VI', '', 'inherit', 'open', 'closed', '', 'vi', '', '', '2017-02-04 20:01:24', '2017-02-04 20:01:24', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/VI.png', 0, 'attachment', 'image/png', 0),
(19, 1, '2017-02-04 20:01:33', '2017-02-04 20:01:33', 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-VI.png', 'cropped-VI.png', '', 'inherit', 'open', 'closed', '', 'cropped-vi-png', '', '', '2017-02-04 20:01:33', '2017-02-04 20:01:33', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-VI.png', 0, 'attachment', 'image/png', 0),
(20, 1, '2017-02-04 20:02:23', '2017-02-04 20:02:23', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2017-02-05 06:38:20', '2017-02-05 06:38:20', '', 49, 'http://localhost/wordpress/wordpress/2017/02/04/20/', 1, 'nav_menu_item', '', 0),
(21, 1, '2017-02-04 20:02:23', '2017-02-04 20:02:23', 'Welcome to your site! This is your homepage, which is what most visitors will see when they come to your site for the first time.', 'Home', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2017-02-04 20:02:23', '2017-02-04 20:02:23', '', 9, 'http://localhost/wordpress/wordpress/2017/02/04/9-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2017-02-04 20:02:24', '2017-02-04 20:02:24', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2017-02-05 06:38:20', '2017-02-05 06:38:20', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/22/', 2, 'nav_menu_item', '', 0),
(23, 1, '2017-02-04 20:02:24', '2017-02-04 20:02:24', 'You might be an artist who would like to introduce yourself and your work here or maybe you&rsquo;re a business with a mission to describe.', 'About', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-02-04 20:02:24', '2017-02-04 20:02:24', '', 10, 'http://localhost/wordpress/wordpress/2017/02/04/10-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2017-02-04 20:02:24', '2017-02-04 20:02:24', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2017-02-05 07:42:03', '2017-02-05 07:42:03', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/24/', 7, 'nav_menu_item', '', 0),
(25, 1, '2017-02-04 20:02:24', '2017-02-04 20:02:24', 'This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.', 'Contact', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2017-02-04 20:02:24', '2017-02-04 20:02:24', '', 11, 'http://localhost/wordpress/wordpress/2017/02/04/11-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2017-02-04 20:02:25', '2017-02-04 20:02:25', '', 'Politics', '', 'publish', 'closed', 'closed', '', '26', '', '', '2017-02-05 06:38:20', '2017-02-05 06:38:20', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/26/', 3, 'nav_menu_item', '', 0),
(27, 1, '2017-02-04 20:02:25', '2017-02-04 20:02:25', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2017-02-04 20:02:25', '2017-02-04 20:02:25', '', 12, 'http://localhost/wordpress/wordpress/2017/02/04/12-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2017-02-04 20:02:26', '2017-02-04 20:02:26', 'This is an example of a homepage section. Homepage sections can be any page other than the homepage itself, including the page that shows your latest blog posts.', 'A homepage section', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2017-02-04 20:02:26', '2017-02-04 20:02:26', '', 13, 'http://localhost/wordpress/wordpress/2017/02/04/13-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2017-02-04 20:02:29', '2017-02-04 20:02:29', '', 'Yelp', '', 'publish', 'closed', 'closed', '', 'yelp', '', '', '2017-02-04 20:02:29', '2017-02-04 20:02:29', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/yelp/', 0, 'nav_menu_item', '', 0),
(35, 1, '2017-02-04 20:02:29', '2017-02-04 20:02:29', '', 'Facebook', '', 'publish', 'closed', 'closed', '', 'facebook', '', '', '2017-02-04 20:02:29', '2017-02-04 20:02:29', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/facebook/', 1, 'nav_menu_item', '', 0),
(36, 1, '2017-02-04 20:02:30', '2017-02-04 20:02:30', '', 'Twitter', '', 'publish', 'closed', 'closed', '', 'twitter', '', '', '2017-02-04 20:02:30', '2017-02-04 20:02:30', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/twitter/', 2, 'nav_menu_item', '', 0),
(37, 1, '2017-02-04 20:02:30', '2017-02-04 20:02:30', '', 'Instagram', '', 'publish', 'closed', 'closed', '', 'instagram', '', '', '2017-02-04 20:02:30', '2017-02-04 20:02:30', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/instagram/', 3, 'nav_menu_item', '', 0),
(38, 1, '2017-02-04 20:02:31', '2017-02-04 20:02:31', '', 'Email', '', 'publish', 'closed', 'closed', '', 'email', '', '', '2017-02-04 20:02:31', '2017-02-04 20:02:31', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/email/', 4, 'nav_menu_item', '', 0),
(39, 1, '2017-02-04 20:06:35', '2017-02-04 20:06:35', '{\n    "twentyseventeen::custom_logo": {\n        "value": 41,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "site_icon": {\n        "value": 42,\n        "type": "option",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '70b6d8ab-6bd8-4f26-a115-7c20722690ac', '', '', '2017-02-04 20:06:35', '2017-02-04 20:06:35', '', 0, 'http://localhost/wordpress/wordpress/?p=39', 0, 'customize_changeset', '', 0),
(40, 1, '2017-02-04 20:05:42', '2017-02-04 20:05:42', '', 'VIT', '', 'inherit', 'open', 'closed', '', 'vit', '', '', '2017-02-04 20:05:42', '2017-02-04 20:05:42', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/VIT.png', 0, 'attachment', 'image/png', 0),
(41, 1, '2017-02-04 20:05:49', '2017-02-04 20:05:49', 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-VIT.png', 'cropped-VIT.png', '', 'inherit', 'open', 'closed', '', 'cropped-vit-png', '', '', '2017-02-04 20:05:49', '2017-02-04 20:05:49', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-VIT.png', 0, 'attachment', 'image/png', 0),
(42, 1, '2017-02-04 20:06:11', '2017-02-04 20:06:11', 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-VIT-1.png', 'cropped-VIT-1.png', '', 'inherit', 'open', 'closed', '', 'cropped-vit-1-png', '', '', '2017-02-04 20:06:11', '2017-02-04 20:06:11', '', 0, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/cropped-VIT-1.png', 0, 'attachment', 'image/png', 0),
(43, 1, '2017-02-04 20:07:43', '2017-02-04 20:07:43', '{\n    "twentyseventeen::header_textcolor": {\n        "value": "#cee234",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::colorscheme": {\n        "value": "custom",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::colorscheme_hue": {\n        "value": 231,\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '59b2241b-b4ba-4f41-8c4f-9b5f49e848b3', '', '', '2017-02-04 20:07:43', '2017-02-04 20:07:43', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/59b2241b-b4ba-4f41-8c4f-9b5f49e848b3/', 0, 'customize_changeset', '', 0),
(44, 1, '2017-02-04 20:08:12', '2017-02-04 20:08:12', '{\n    "twentyseventeen::colorscheme": {\n        "value": "custom",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::colorscheme_hue": {\n        "value": 72,\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '43e1429e-6f3a-4814-9a25-42f22f66706c', '', '', '2017-02-04 20:08:12', '2017-02-04 20:08:12', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/43e1429e-6f3a-4814-9a25-42f22f66706c/', 0, 'customize_changeset', '', 0),
(45, 1, '2017-02-04 20:09:10', '2017-02-04 20:09:10', '{\n    "twentyseventeen::header_textcolor": {\n        "value": "#ffffff",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::colorscheme": {\n        "value": "light",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::colorscheme_hue": {\n        "value": 64,\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd7810bc8-3727-4d4d-938c-9ea739563669', '', '', '2017-02-04 20:09:10', '2017-02-04 20:09:10', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/d7810bc8-3727-4d4d-938c-9ea739563669/', 0, 'customize_changeset', '', 0),
(46, 1, '2017-02-04 20:17:36', '2017-02-04 20:17:36', '{\n    "nav_menu_item[31]": {\n        "value": {\n            "menu_item_parent": 0,\n            "object_id": 10,\n            "object": "page",\n            "type": "post_type",\n            "type_label": "Page",\n            "url": "http://localhost/wordpress/wordpress/about/",\n            "title": "News",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "nav_menu_term_id": 3,\n            "position": 2,\n            "status": "publish",\n            "original_title": "About",\n            "_invalid": false\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[32]": {\n        "value": {\n            "menu_item_parent": 0,\n            "object_id": 12,\n            "object": "page",\n            "type": "post_type",\n            "type_label": "Page",\n            "url": "http://localhost/wordpress/wordpress/blog/",\n            "title": "Politics",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "nav_menu_term_id": 3,\n            "position": 3,\n            "status": "publish",\n            "original_title": "Blog",\n            "_invalid": false\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menus_created_posts": {\n        "value": [\n            47,\n            48,\n            49,\n            50,\n            51,\n            52\n        ],\n        "type": "option",\n        "user_id": 1\n    },\n    "nav_menu_item[-100957559]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-1807561215]": {\n        "value": {\n            "object_id": 48,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 4,\n            "type": "post_type",\n            "title": "Sports",\n            "url": "http://localhost/wordpress/wordpress/?page_id=48",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "Sports",\n            "nav_menu_term_id": 3,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "twentyseventeen::nav_menu_locations[top]": {\n        "value": 0,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "nav_menu[3]": {\n        "value": false,\n        "type": "nav_menu",\n        "user_id": 1\n    },\n    "nav_menu_item[33]": {\n        "value": {\n            "menu_item_parent": 0,\n            "object_id": 11,\n            "object": "page",\n            "type": "post_type",\n            "type_label": "Page",\n            "url": "http://localhost/wordpress/wordpress/contact/",\n            "title": "",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "nav_menu_term_id": 3,\n            "position": 6,\n            "status": "publish",\n            "original_title": "Contact",\n            "_invalid": false\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-935958695]": {\n        "value": {\n            "object_id": 49,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 5,\n            "type": "post_type",\n            "title": "Entertainment",\n            "url": "http://localhost/wordpress/wordpress/?page_id=49",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "Entertainment",\n            "nav_menu_term_id": 3,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-1636074227]": {\n        "value": {\n            "object_id": 50,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 7,\n            "type": "post_type",\n            "title": "Contact",\n            "url": "http://localhost/wordpress/wordpress/?page_id=50",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "Contact",\n            "nav_menu_term_id": 3,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[22]": {\n        "value": {\n            "menu_item_parent": 0,\n            "object_id": 10,\n            "object": "page",\n            "type": "post_type",\n            "type_label": "Page",\n            "url": "http://localhost/wordpress/wordpress/about/",\n            "title": "News",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "nav_menu_term_id": 2,\n            "position": 2,\n            "status": "publish",\n            "original_title": "About",\n            "_invalid": false\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[24]": {\n        "value": {\n            "menu_item_parent": 0,\n            "object_id": 11,\n            "object": "page",\n            "type": "post_type",\n            "type_label": "Page",\n            "url": "http://localhost/wordpress/wordpress/contact/",\n            "title": "",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "nav_menu_term_id": 2,\n            "position": 6,\n            "status": "publish",\n            "original_title": "Contact",\n            "_invalid": false\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[26]": {\n        "value": {\n            "menu_item_parent": 0,\n            "object_id": 12,\n            "object": "page",\n            "type": "post_type",\n            "type_label": "Page",\n            "url": "http://localhost/wordpress/wordpress/blog/",\n            "title": "Politics",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "nav_menu_term_id": 2,\n            "position": 3,\n            "status": "publish",\n            "original_title": "Blog",\n            "_invalid": false\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[28]": {\n        "value": {\n            "menu_item_parent": 0,\n            "object_id": 13,\n            "object": "page",\n            "type": "post_type",\n            "type_label": "Page",\n            "url": "http://localhost/wordpress/wordpress/a-homepage-section/",\n            "title": "",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "nav_menu_term_id": 2,\n            "position": 7,\n            "status": "publish",\n            "original_title": "A homepage section",\n            "_invalid": false\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-1634869030]": {\n        "value": {\n            "object_id": 51,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 4,\n            "type": "post_type",\n            "title": "Sports",\n            "url": "http://localhost/wordpress/wordpress/?page_id=51",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "Sports",\n            "nav_menu_term_id": 2,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-1518160675]": {\n        "value": {\n            "object_id": 52,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 5,\n            "type": "post_type",\n            "title": "Entertainment",\n            "url": "http://localhost/wordpress/wordpress/?page_id=52",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "Entertainment",\n            "nav_menu_term_id": 2,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'fcb1f350-e8d9-4429-8ae2-4b81a942375e', '', '', '2017-02-04 20:17:36', '2017-02-04 20:17:36', '', 0, 'http://localhost/wordpress/wordpress/?p=46', 0, 'customize_changeset', '', 0),
(47, 1, '2017-02-04 20:17:36', '2017-02-04 20:17:36', '', 'Politics', '', 'publish', 'closed', 'closed', '', 'politics', '', '', '2017-02-04 20:17:36', '2017-02-04 20:17:36', '', 0, 'http://localhost/wordpress/wordpress/?page_id=47', 0, 'page', '', 0),
(48, 1, '2017-02-04 20:17:37', '2017-02-04 20:17:37', '', 'Sports', '', 'publish', 'closed', 'closed', '', 'sports', '', '', '2017-02-04 20:17:37', '2017-02-04 20:17:37', '', 0, 'http://localhost/wordpress/wordpress/?page_id=48', 0, 'page', '', 0),
(49, 1, '2017-02-04 20:17:37', '2017-02-04 20:17:37', '<h1>MOVIES              MUSIC</h1>\r\nINDIANA JONES              Thinking out Loud--ED\r\n\r\nBEWOLF                           Gospel-Vitus\r\n\r\nSUPERGIRL                      Creamer-wayne', 'Entertainment', '', 'publish', 'closed', 'closed', '', 'entertainment', '', '', '2017-02-05 08:09:10', '2017-02-05 08:09:10', '', 0, 'http://localhost/wordpress/wordpress/?page_id=49', 0, 'page', '', 1),
(50, 1, '2017-02-04 20:17:38', '2017-02-04 20:17:38', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact-2', '', '', '2017-02-04 20:17:38', '2017-02-04 20:17:38', '', 0, 'http://localhost/wordpress/wordpress/?page_id=50', 0, 'page', '', 0),
(51, 1, '2017-02-04 20:17:39', '2017-02-04 20:17:39', 'FOOTBALL       FORMULA 1     CRICKET      BASKETBALL\r\n\r\nLIVE UPDATES --------Coming Soon', 'Sports', '', 'publish', 'closed', 'closed', '', 'sports-2', '', '', '2017-02-05 08:11:43', '2017-02-05 08:11:43', '', 0, 'http://localhost/wordpress/wordpress/?page_id=51', 0, 'page', '', 0),
(52, 1, '2017-02-04 20:17:39', '2017-02-04 20:17:39', '<h1>MUSIC                                         MOVIES</h1>\r\nVITUS: releases another music on the                 Watch movies @ vicavelly''s\r\n21st of july\r\n\r\n[video poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4"][/video]', 'Entertainment', '', 'trash', 'closed', 'closed', '', 'entertainment-2__trashed', '', '', '2017-02-05 04:33:03', '2017-02-05 04:33:03', '', 0, 'http://localhost/wordpress/wordpress/?page_id=52', 0, 'page', '', 0),
(54, 1, '2017-02-04 20:17:36', '2017-02-04 20:17:36', '', 'Politics', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2017-02-04 20:17:36', '2017-02-04 20:17:36', '', 47, 'http://localhost/wordpress/wordpress/2017/02/04/47-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2017-02-04 20:17:37', '2017-02-04 20:17:37', '', 'Sports', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2017-02-04 20:17:37', '2017-02-04 20:17:37', '', 48, 'http://localhost/wordpress/wordpress/2017/02/04/48-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2017-02-04 20:17:37', '2017-02-04 20:17:37', '', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2017-02-04 20:17:37', '2017-02-04 20:17:37', '', 49, 'http://localhost/wordpress/wordpress/2017/02/04/49-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2017-02-04 20:17:38', '2017-02-04 20:17:38', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2017-02-04 20:17:38', '2017-02-04 20:17:38', '', 50, 'http://localhost/wordpress/wordpress/2017/02/04/50-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2017-02-04 20:17:39', '2017-02-04 20:17:39', '', 'Sports', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2017-02-04 20:17:39', '2017-02-04 20:17:39', '', 51, 'http://localhost/wordpress/wordpress/2017/02/04/51-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2017-02-04 20:17:39', '2017-02-04 20:17:39', '', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2017-02-04 20:17:39', '2017-02-04 20:17:39', '', 52, 'http://localhost/wordpress/wordpress/2017/02/04/52-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2017-02-04 20:17:43', '2017-02-04 20:17:43', ' ', '', '', 'publish', 'closed', 'closed', '', '66', '', '', '2017-02-05 06:38:20', '2017-02-05 06:38:20', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/66/', 4, 'nav_menu_item', '', 0),
(68, 1, '2017-02-04 20:18:17', '2017-02-04 20:18:17', '{\n    "twentyseventeen::nav_menu_locations[top]": {\n        "value": 2,\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd50f264f-2ccb-49f1-a6dd-e7114e9db104', '', '', '2017-02-04 20:18:17', '2017-02-04 20:18:17', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/d50f264f-2ccb-49f1-a6dd-e7114e9db104/', 0, 'customize_changeset', '', 0),
(69, 1, '2017-02-04 20:19:52', '0000-00-00 00:00:00', '{\n    "nav_menu_item[28]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-1314252187]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-23967637]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-784088066]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-2128468383]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "twentyseventeen::nav_menu_locations[top]": {\n        "value": 0,\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "nav_menu[2]": {\n        "value": false,\n        "type": "nav_menu",\n        "user_id": 1\n    },\n    "nav_menu_item[67]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '05be4ecb-7ac0-436c-b106-8b80e21905f2', '', '', '2017-02-04 20:20:54', '2017-02-04 20:20:54', '', 0, 'http://localhost/wordpress/wordpress/?p=69', 0, 'customize_changeset', '', 0),
(70, 1, '2017-02-04 20:24:20', '2017-02-04 20:24:20', '{\n    "nav_menu_item[53]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[55]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[28]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[57]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[59]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[61]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[63]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd5bbddbb-83e5-4586-b3c9-eb633e9f4379', '', '', '2017-02-04 20:24:20', '2017-02-04 20:24:20', '', 0, 'http://localhost/wordpress/wordpress/2017/02/04/d5bbddbb-83e5-4586-b3c9-eb633e9f4379/', 0, 'customize_changeset', '', 0),
(71, 1, '2017-02-04 20:42:44', '2017-02-04 20:42:44', '{\n    "page_for_posts": {\n        "value": "9",\n        "type": "option",\n        "user_id": 1\n    },\n    "widget_text[4]": {\n        "value": {\n            "encoded_serialized_instance": "YTozOntzOjU6InRpdGxlIjtzOjc6IkZpbmQgVXMiO3M6NDoidGV4dCI7czoyMjI6IjxwPjxzdHJvbmc+QWRkcmVzczwvc3Ryb25nPjxiciAvPlZhbGxleSBWaWV3IFVuaXZlcnNpdHk8YnIgLz5EZXBhcnRtZW50IG9mIEVuZ2luZWVyaW5nIFNjaWVuY2U8L3A+PHA+PHN0cm9uZz5Ib3Vyczwvc3Ryb25nPjxiciAvPk1vbmRheSZtZGFzaDtGcmlkYXk6IDk6MDBBTSZuZGFzaDs1OjAwUE08YnIgLz5TYXR1cmRheSAmYW1wOyBTdW5kYXk6IDExOjAwQU0mbmRhc2g7MzowMFBNPC9wPiI7czo2OiJmaWx0ZXIiO2I6MDt9",\n            "title": "Find Us",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "de776707ce1b198e565c045fed133db3"\n        },\n        "type": "option",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '87d017a9-31c5-4890-9df7-aa4a9fcd6248', '', '', '2017-02-04 20:42:44', '2017-02-04 20:42:44', '', 0, 'http://localhost/wordpress/wordpress/?p=71', 0, 'customize_changeset', '', 0),
(72, 1, '2017-02-05 08:04:15', '2017-02-05 08:04:15', '[video poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4"][/video]\n\nYou might be an artist who would like to introduce yourself and your work here or maybe you’re a business with a mission to describe.', 'News', '', 'inherit', 'closed', 'closed', '', '10-autosave-v1', '', '', '2017-02-05 08:04:15', '2017-02-05 08:04:15', '', 10, 'http://localhost/wordpress/wordpress/2017/02/04/10-autosave-v1/', 0, 'revision', '', 0),
(74, 1, '2017-02-04 20:30:33', '2017-02-04 20:30:33', '[video width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412-1.mp4"][/video]\r\n\r\nYou might be an artist who would like to introduce yourself and your work here or maybe you’re a business with a mission to describe.', 'News', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-02-04 20:30:33', '2017-02-04 20:30:33', '', 10, 'http://localhost/wordpress/wordpress/2017/02/04/10-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2017-02-04 20:46:14', '2017-02-04 20:46:14', '{\n    "widget_text[5]": {\n        "value": {\n            "encoded_serialized_instance": "YTozOntzOjU6InRpdGxlIjtzOjE1OiJBYm91dCBUaGlzIFNpdGUiO3M6NDoidGV4dCI7czoxNzI6IkZvdW5kZWQgYnkgRW1tYW51ZWwgVml0dXMsIA0KVk5BIGlzIGEgTWVkaWEgQ29ycG9yYXRpb24gZGV2ZWxvcGVkIHRvIHByZXNlbnQgdG8gdGhlIHBlb3BsZSB0cnVlIGhhcHBlbmluZ3MsIGFyb3VuZCBhbmQgd2l0aGluICB0aGVpciB2aWNpbml0eS4NClRydWx5IGEgbWVkaWEgZm9yIHRoZSBwZW9wbGUiO3M6NjoiZmlsdGVyIjtiOjA7fQ==",\n            "title": "About This Site",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "75feb5771fda17ef3c40ef7614f9b8df"\n        },\n        "type": "option",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'a379e8a5-6a28-475a-82ca-da09fee63fae', '', '', '2017-02-04 20:46:14', '2017-02-04 20:46:14', '', 0, 'http://localhost/wordpress/wordpress/?p=75', 0, 'customize_changeset', '', 0),
(76, 1, '2017-02-04 20:50:41', '2017-02-04 20:50:41', '{\n    "sidebars_widgets[sidebar-3]": {\n        "value": [\n            "text-5",\n            "rss-3"\n        ],\n        "type": "option",\n        "user_id": 1\n    },\n    "widget_pages[3]": {\n        "value": [],\n        "type": "option",\n        "user_id": 1\n    },\n    "sidebars_widgets[wp_inactive_widgets]": {\n        "value": [\n            "search-4"\n        ],\n        "type": "option",\n        "user_id": 1\n    },\n    "widget_rss[3]": {\n        "value": {\n            "encoded_serialized_instance": "YTo2OntzOjU6InRpdGxlIjtzOjEwOiJMaXZlIEZlZWRzIjtzOjM6InVybCI7czo1NzoiaHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj1ELTEwQzluNzRKMCZmZWF0dXJlPXNoYXJlIjtzOjU6Iml0ZW1zIjtpOjEwO3M6MTI6InNob3dfc3VtbWFyeSI7aToxO3M6MTE6InNob3dfYXV0aG9yIjtpOjA7czo5OiJzaG93X2RhdGUiO2k6MDt9",\n            "title": "Live Feeds",\n            "is_widget_customizer_js_value": true,\n            "instance_hash_key": "590d4d7d2cbd55fc45bbb6c4dcdd19e2"\n        },\n        "type": "option",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '79d2dfae-3391-4d1d-ad58-4f874ee0db38', '', '', '2017-02-04 20:50:41', '2017-02-04 20:50:41', '', 0, 'http://localhost/wordpress/wordpress/?p=76', 0, 'customize_changeset', '', 0),
(77, 1, '2017-02-04 20:51:46', '0000-00-00 00:00:00', '{\n    "show_on_front": {\n        "value": "page",\n        "type": "option",\n        "user_id": 1\n    },\n    "twentyseventeen::page_layout": {\n        "value": "two-column",\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '67888334-aa6c-472e-a9bf-c1bec5b3714d', '', '', '2017-02-04 20:52:46', '2017-02-04 20:52:46', '', 0, 'http://localhost/wordpress/wordpress/?p=77', 0, 'customize_changeset', '', 0);
INSERT INTO `wp_wordpressposts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(78, 1, '2017-02-04 23:00:04', '2017-02-04 23:00:04', '[video width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4" poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" loop="true" autoplay="true" preload="auto"][/video]', '', '', 'publish', 'open', 'open', '', '78', '', '', '2017-02-04 23:00:04', '2017-02-04 23:00:04', '', 0, 'http://localhost/wordpress/wordpress/?p=78', 0, 'post', '', 0),
(79, 1, '2017-02-04 22:59:15', '2017-02-04 22:59:15', '', 'vvvvv', '', 'inherit', 'open', 'closed', '', 'vvvvv', '', '', '2017-02-04 22:59:15', '2017-02-04 22:59:15', '', 78, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png', 0, 'attachment', 'image/png', 0),
(80, 1, '2017-02-04 23:00:04', '2017-02-04 23:00:04', '[video width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4" poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" loop="true" autoplay="true" preload="auto"][/video]', '', '', 'inherit', 'closed', 'closed', '', '78-revision-v1', '', '', '2017-02-04 23:00:04', '2017-02-04 23:00:04', '', 78, 'http://localhost/wordpress/wordpress/2017/02/04/78-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2017-02-04 23:39:00', '2017-02-04 23:39:00', '', 'Home', '', 'inherit', 'closed', 'closed', '', '9-autosave-v1', '', '', '2017-02-04 23:39:00', '2017-02-04 23:39:00', '', 9, 'http://localhost/wordpress/wordpress/2017/02/04/9-autosave-v1/', 0, 'revision', '', 0),
(82, 1, '2017-02-04 23:39:06', '2017-02-04 23:39:06', '', 'Home', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2017-02-04 23:39:06', '2017-02-04 23:39:06', '', 9, 'http://localhost/wordpress/wordpress/2017/02/04/9-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2017-02-04 23:41:25', '2017-02-04 23:41:25', 'hi therkfldkl;kl;dkl;fkl;sdkf\r\n\r\ndsfdklxfjdsj\r\n\r\ndkfjkdsljf\r\n\r\nsdfkldjsfkl\r\n\r\nsdfkk', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2017-02-04 23:41:25', '2017-02-04 23:41:25', '', 49, 'http://localhost/wordpress/wordpress/2017/02/04/49-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2017-02-04 23:42:13', '2017-02-04 23:42:13', 'ljdgkljklfjdlkjfd', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2017-02-04 23:42:13', '2017-02-04 23:42:13', '', 52, 'http://localhost/wordpress/wordpress/2017/02/04/52-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2017-02-05 04:16:06', '2017-02-05 04:16:06', '<h1>MUSIC                                         MOVIES</h1>\nVITUS: releases another music on the                 Watch movies @ vicavelly''s\n21st of july\n\n[video poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4"][/video]', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '52-autosave-v1', '', '', '2017-02-05 04:16:06', '2017-02-05 04:16:06', '', 52, 'http://localhost/wordpress/wordpress/2017/02/04/52-autosave-v1/', 0, 'revision', '', 0),
(86, 1, '2017-02-04 23:44:34', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-02-04 23:44:34', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/wordpress/?p=86', 0, 'post', '', 0),
(87, 1, '2017-02-05 04:10:25', '2017-02-05 04:10:25', '', 'IMG_20170203_111924_036', '', 'inherit', 'open', 'closed', '', 'img_20170203_111924_036', '', '', '2017-02-05 04:10:25', '2017-02-05 04:10:25', '', 52, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/IMG_20170203_111924_036.jpg', 0, 'attachment', 'image/jpeg', 0),
(88, 1, '2017-02-05 04:12:29', '2017-02-05 04:12:29', '', 'IMG_20170203_111924_036', '', 'inherit', 'open', 'closed', '', 'img_20170203_111924_036-2', '', '', '2017-02-05 04:12:29', '2017-02-05 04:12:29', '', 52, 'http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/IMG_20170203_111924_036-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(89, 1, '2017-02-05 04:13:58', '2017-02-05 04:13:58', '<h1>MUSIC                                              MOVIES</h1>\r\nVITUS: releases another music on the                         Watch movies @ vicavelly''s\r\n21st of july                                                                     <img class="alignright wp-image-87 size-thumbnail" src="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/IMG_20170203_111924_036-150x150.jpg" width="150" height="150" />\r\n\r\n[video poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4"][/video]', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2017-02-05 04:13:58', '2017-02-05 04:13:58', '', 52, 'http://localhost/wordpress/wordpress/2017/02/05/52-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2017-02-05 04:16:35', '2017-02-05 04:16:35', '<h1>MUSIC                                         MOVIES</h1>\r\nVITUS: releases another music on the                 Watch movies @ vicavelly''s\r\n21st of july\r\n\r\n[video poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4"][/video]', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '52-revision-v1', '', '', '2017-02-05 04:16:35', '2017-02-05 04:16:35', '', 52, 'http://localhost/wordpress/wordpress/2017/02/05/52-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2017-02-05 07:33:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-02-05 07:33:28', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress/wordpress/?p=92', 0, 'post', '', 0),
(93, 1, '2017-02-05 07:42:03', '2017-02-05 07:42:03', '{\n    "nav_menu_item[67]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[24]": {\n        "value": {\n            "menu_item_parent": 0,\n            "object_id": 11,\n            "object": "page",\n            "type": "post_type",\n            "type_label": "Page",\n            "url": "http://localhost/wordpress/wordpress/contact/",\n            "title": "",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "nav_menu_term_id": 2,\n            "position": 7,\n            "status": "publish",\n            "original_title": "Contact",\n            "_invalid": false\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[-2040185308]": {\n        "value": {\n            "object_id": 49,\n            "object": "page",\n            "menu_item_parent": 0,\n            "position": 6,\n            "type": "post_type",\n            "title": "Entertainment",\n            "url": "http://localhost/wordpress/wordpress/entertainment/",\n            "target": "",\n            "attr_title": "",\n            "description": "",\n            "classes": "",\n            "xfn": "",\n            "status": "publish",\n            "original_title": "Entertainment",\n            "nav_menu_term_id": 2,\n            "_invalid": false,\n            "type_label": "Page"\n        },\n        "type": "nav_menu_item",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3cee0edc-211b-4a84-a568-4b9a295002da', '', '', '2017-02-05 07:42:03', '2017-02-05 07:42:03', '', 0, 'http://localhost/wordpress/wordpress/2017/02/05/3cee0edc-211b-4a84-a568-4b9a295002da/', 0, 'customize_changeset', '', 0),
(94, 1, '2017-02-05 07:42:03', '2017-02-05 07:42:03', ' ', '', '', 'publish', 'closed', 'closed', '', '94', '', '', '2017-02-05 07:42:03', '2017-02-05 07:42:03', '', 0, 'http://localhost/wordpress/wordpress/2017/02/05/94/', 6, 'nav_menu_item', '', 0),
(95, 1, '2017-02-05 07:43:31', '2017-02-05 07:43:31', '{\n    "twentyseventeen::panel_1": {\n        "value": "9",\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '92421827-e91a-486c-a257-e1ff8e70cc20', '', '', '2017-02-05 07:43:31', '2017-02-05 07:43:31', '', 0, 'http://localhost/wordpress/wordpress/2017/02/05/92421827-e91a-486c-a257-e1ff8e70cc20/', 0, 'customize_changeset', '', 0),
(96, 1, '2017-02-05 07:56:05', '2017-02-05 07:56:05', '{\n    "show_on_front": {\n        "value": "page",\n        "type": "option",\n        "user_id": 1\n    },\n    "page_on_front": {\n        "value": "98",\n        "type": "option",\n        "user_id": 1\n    },\n    "nav_menus_created_posts": {\n        "value": [\n            97,\n            98\n        ],\n        "type": "option",\n        "user_id": 1\n    },\n    "twentyseventeen::panel_2": {\n        "value": "0",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::panel_3": {\n        "value": "0",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::panel_4": {\n        "value": "0",\n        "type": "theme_mod",\n        "user_id": 1\n    },\n    "twentyseventeen::panel_1": {\n        "value": "0",\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '9be7a267-8bed-4edd-b264-b480028d4492', '', '', '2017-02-05 07:56:05', '2017-02-05 07:56:05', '', 0, 'http://localhost/wordpress/wordpress/?p=96', 0, 'customize_changeset', '', 0),
(97, 1, '2017-02-05 07:56:05', '2017-02-05 07:56:05', '', 'Hi', '', 'publish', 'closed', 'closed', '', 'hi', '', '', '2017-02-05 07:56:05', '2017-02-05 07:56:05', '', 0, 'http://localhost/wordpress/wordpress/?page_id=97', 0, 'page', '', 0),
(98, 1, '2017-02-05 07:56:06', '2017-02-05 07:56:06', '<h1>UPDATES</h1>\r\n<h3>CRIME       TECH       MISCELLANEOUS</h3>\r\nThis is an CRIME page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Beware of strangers at night, they might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.\r\n\r\nbefore u know it you are gone...... Have fun this weekend!</blockquote>\r\n&nbsp;', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-02-05 08:02:46', '2017-02-05 08:02:46', '', 9, 'http://localhost/wordpress/wordpress/?page_id=98', 0, 'page', '', 0),
(100, 1, '2017-02-05 07:56:05', '2017-02-05 07:56:05', '', 'Hi', '', 'inherit', 'closed', 'closed', '', '97-revision-v1', '', '', '2017-02-05 07:56:05', '2017-02-05 07:56:05', '', 97, 'http://localhost/wordpress/wordpress/2017/02/05/97-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2017-02-05 07:56:06', '2017-02-05 07:56:06', '', 'Home', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-02-05 07:56:06', '2017-02-05 07:56:06', '', 98, 'http://localhost/wordpress/wordpress/2017/02/05/98-revision-v1/', 0, 'revision', '', 0),
(103, 1, '2017-02-05 08:02:25', '2017-02-05 08:02:25', '<h1>UPDATES</h1>\n<h3>CRIME       TECH       MISCELLANEOUS</h3>\nThis is an CRIME page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Beware of strangers at night, they might say something like this:\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\n...or something like this:\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.\n\nbefor . Have fun!</blockquote>\n&nbsp;', 'Home', '', 'inherit', 'closed', 'closed', '', '98-autosave-v1', '', '', '2017-02-05 08:02:25', '2017-02-05 08:02:25', '', 98, 'http://localhost/wordpress/wordpress/2017/02/05/98-autosave-v1/', 0, 'revision', '', 0),
(104, 1, '2017-02-05 07:58:17', '2017-02-05 07:58:17', '<h1>UPDATES</h1>\r\n<h3>CRIME                       TECH                           MISCELLANEOUS</h3>\r\n&nbsp;', 'Home', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-02-05 07:58:17', '2017-02-05 07:58:17', '', 98, 'http://localhost/wordpress/wordpress/2017/02/05/98-revision-v1/', 0, 'revision', '', 0),
(105, 1, '2017-02-05 07:58:52', '2017-02-05 07:58:52', '<h1>UPDATES</h1>\r\n<h3>CRIME                       TECH             MISCELLANEOUS</h3>\r\n&nbsp;', 'Home', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-02-05 07:58:52', '2017-02-05 07:58:52', '', 98, 'http://localhost/wordpress/wordpress/2017/02/05/98-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2017-02-05 07:59:21', '2017-02-05 07:59:21', '<h1>UPDATES</h1>\r\n<h3>CRIME       TECH       MISCELLANEOUS</h3>\r\n&nbsp;', 'Home', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-02-05 07:59:21', '2017-02-05 07:59:21', '', 98, 'http://localhost/wordpress/wordpress/2017/02/05/98-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2017-02-05 08:00:03', '2017-02-05 08:00:03', '{\n    "nav_menu_item[99]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    },\n    "nav_menu_item[101]": {\n        "value": false,\n        "type": "nav_menu_item",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '51999b32-587e-418f-9413-9c80b70c67d9', '', '', '2017-02-05 08:00:03', '2017-02-05 08:00:03', '', 0, 'http://localhost/wordpress/wordpress/2017/02/05/51999b32-587e-418f-9413-9c80b70c67d9/', 0, 'customize_changeset', '', 0),
(108, 1, '2017-02-05 08:02:46', '2017-02-05 08:02:46', '<h1>UPDATES</h1>\r\n<h3>CRIME       TECH       MISCELLANEOUS</h3>\r\nThis is an CRIME page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Beware of strangers at night, they might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.\r\n\r\nbefore u know it you are gone...... Have fun this weekend!</blockquote>\r\n&nbsp;', 'Home', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2017-02-05 08:02:46', '2017-02-05 08:02:46', '', 98, 'http://localhost/wordpress/wordpress/2017/02/05/98-revision-v1/', 0, 'revision', '', 0),
(109, 1, '2017-02-05 08:05:01', '2017-02-05 08:05:01', '[video poster="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/vvvvv.png" width="432" height="240" mp4="http://localhost/wordpress/wordpress/wp-content/uploads/2017/02/20170204113412.mp4"][/video]\r\n\r\nWelcome to VNA news site....... Receive live updates here.', 'News', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-02-05 08:05:01', '2017-02-05 08:05:01', '', 10, 'http://localhost/wordpress/wordpress/2017/02/05/10-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2017-02-05 08:07:00', '2017-02-05 08:07:00', 'CONTACT US ON +233579237950\r\n\r\n&nbsp;', 'Contact', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2017-02-05 08:07:00', '2017-02-05 08:07:00', '', 11, 'http://localhost/wordpress/wordpress/2017/02/05/11-revision-v1/', 0, 'revision', '', 0),
(111, 1, '2017-02-05 08:08:22', '2017-02-05 08:08:22', '<h1>MOVIES              MUSIC</h1>\nINDIANA JONES              Thinking out Loud--ED\n\nBEWOLF', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '49-autosave-v1', '', '', '2017-02-05 08:08:22', '2017-02-05 08:08:22', '', 49, 'http://localhost/wordpress/wordpress/2017/02/05/49-autosave-v1/', 0, 'revision', '', 0),
(112, 1, '2017-02-05 08:09:10', '2017-02-05 08:09:10', '<h1>MOVIES              MUSIC</h1>\r\nINDIANA JONES              Thinking out Loud--ED\r\n\r\nBEWOLF                           Gospel-Vitus\r\n\r\nSUPERGIRL                      Creamer-wayne', 'Entertainment', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2017-02-05 08:09:10', '2017-02-05 08:09:10', '', 49, 'http://localhost/wordpress/wordpress/2017/02/05/49-revision-v1/', 0, 'revision', '', 0),
(113, 1, '2017-02-05 08:10:23', '2017-02-05 08:10:23', '<h1>FOOTBALL  FORMULA 1 CRICKET  BASKETBALL</h1>', 'Sports', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2017-02-05 08:10:23', '2017-02-05 08:10:23', '', 51, 'http://localhost/wordpress/wordpress/2017/02/05/51-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2017-02-05 08:11:09', '2017-02-05 08:11:09', 'FOOTBALL       FORMULA 1     CRICKET      BASKETBALL', 'Sports', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2017-02-05 08:11:09', '2017-02-05 08:11:09', '', 51, 'http://localhost/wordpress/wordpress/2017/02/05/51-revision-v1/', 0, 'revision', '', 0),
(115, 1, '2017-02-05 08:11:43', '2017-02-05 08:11:43', 'FOOTBALL       FORMULA 1     CRICKET      BASKETBALL\r\n\r\nLIVE UPDATES --------Coming Soon', 'Sports', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2017-02-05 08:11:43', '2017-02-05 08:11:43', '', 51, 'http://localhost/wordpress/wordpress/2017/02/05/51-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2017-02-05 08:12:58', '2017-02-05 08:12:58', '<h3>Stay Tuned for updated list of Today''s Politics.....</h3>', 'Blog', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2017-02-05 08:12:58', '2017-02-05 08:12:58', '', 12, 'http://localhost/wordpress/wordpress/2017/02/05/12-revision-v1/', 0, 'revision', '', 0),
(117, 1, '2017-02-05 08:14:55', '2017-02-05 08:14:55', '{\n    "twentyseventeen::panel_2": {\n        "value": "9",\n        "type": "theme_mod",\n        "user_id": 1\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f9f1231f-cc5d-4014-91f1-6ebdc59ae37c', '', '', '2017-02-05 08:14:55', '2017-02-05 08:14:55', '', 0, 'http://localhost/wordpress/wordpress/?p=117', 0, 'customize_changeset', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpresstermmeta`
--

CREATE TABLE IF NOT EXISTS `wp_wordpresstermmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpressterms`
--

CREATE TABLE IF NOT EXISTS `wp_wordpressterms` (
`term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `wp_wordpressterms`
--

INSERT INTO `wp_wordpressterms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'News', 'news', 0),
(4, 'Social Links Menu', 'social-links-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpressterm_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_wordpressterm_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wordpressterm_relationships`
--

INSERT INTO `wp_wordpressterm_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(20, 2, 0),
(22, 2, 0),
(24, 2, 0),
(26, 2, 0),
(34, 4, 0),
(35, 4, 0),
(36, 4, 0),
(37, 4, 0),
(38, 4, 0),
(66, 2, 0),
(78, 1, 0),
(94, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpressterm_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_wordpressterm_taxonomy` (
`term_taxonomy_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `wp_wordpressterm_taxonomy`
--

INSERT INTO `wp_wordpressterm_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 6),
(4, 4, 'nav_menu', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpressusermeta`
--

CREATE TABLE IF NOT EXISTS `wp_wordpressusermeta` (
`umeta_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=27 ;

--
-- Dumping data for table `wp_wordpressusermeta`
--

INSERT INTO `wp_wordpressusermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_wordpresscapabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_wordpressuser_level', '10'),
(13, 1, 'dismissed_wp_pointers', ''),
(14, 1, 'show_welcome_panel', '1'),
(15, 1, 'session_tokens', 'a:2:{s:64:"8573a032a361bfd509121823790536c645038107e0f92d060e0a20a17f19b425";a:4:{s:10:"expiration";i:1487148606;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36";s:5:"login";i:1485939006;}s:64:"1f2eff8aef8b70765da97fd08f6d9174b8527da25f92d020bdfbf9aee720ff8d";a:4:{s:10:"expiration";i:1486326662;s:2:"ip";s:3:"::1";s:2:"ua";s:114:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36";s:5:"login";i:1486153862;}}'),
(16, 1, 'wp_wordpressdashboard_quick_press_last_post_id', '3'),
(17, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(18, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(19, 1, 'nav_menu_recently_edited', '2'),
(20, 1, 'wp_wordpressuser-settings', 'libraryContent=browse&editor=tinymce&hidetb=1&post_dfw=off&mfold=o'),
(21, 1, 'wp_wordpressuser-settings-time', '1486278048'),
(22, 1, 'meta-box-order_page', 'a:3:{s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:70:"revisionsdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(23, 1, 'screen_layout_page', '2'),
(24, 1, 'closedpostboxes_page', 'a:0:{}'),
(25, 1, 'metaboxhidden_page', 'a:2:{i:0;s:12:"postimagediv";i:1;s:7:"slugdiv";}'),
(26, 1, 'wp_wordpressmedia_library_mode', 'list');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpressusers`
--

CREATE TABLE IF NOT EXISTS `wp_wordpressusers` (
`ID` bigint(20) unsigned NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wp_wordpressusers`
--

INSERT INTO `wp_wordpressusers` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BXPfb//fYURWJZFrPUXx3a9XUN.THC1', 'admin', 'emmanuelvitus01@gmail.com', '', '2017-02-01 08:49:51', '', 0, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wordpresswpeditor_settings`
--

CREATE TABLE IF NOT EXISTS `wp_wordpresswpeditor_settings` (
  `key` varchar(50) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_wordpresswpeditor_settings`
--

INSERT INTO `wp_wordpresswpeditor_settings` (`key`, `value`) VALUES
('admin_page_roles', 'a:3:{s:8:"settings";s:14:"manage_options";s:12:"theme-editor";s:11:"edit_themes";s:13:"plugin-editor";s:12:"edit_plugins";}'),
('enable_plugin_active_line', '1'),
('enable_plugin_line_numbers', '1'),
('enable_plugin_line_wrapping', '1'),
('enable_post_active_line', '1'),
('enable_post_editor', '1'),
('enable_post_line_numbers', '1'),
('enable_post_line_wrapping', '1'),
('enable_theme_active_line', '1'),
('enable_theme_line_numbers', '1'),
('enable_theme_line_wrapping', '1'),
('hide_default_plugin_editor', '1'),
('hide_default_theme_editor', '1'),
('plugin_editor_allowed_extensions', 'php~js~css~txt~htm~html~jpg~jpeg~png~gif~sql~po~less~xml'),
('plugin_file_upload', '1'),
('plugin_indent_unit', '2'),
('post_indent_unit', '2'),
('replace_plugin_edit_links', '1'),
('theme_editor_allowed_extensions', 'php~js~css~txt~htm~html~jpg~jpeg~png~gif~sql~po~less~xml'),
('theme_file_upload', '1'),
('theme_indent_unit', '2'),
('upgrade', '1'),
('version', '1.2.6.3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_wordpresscommentmeta`
--
ALTER TABLE `wp_wordpresscommentmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `comment_id` (`comment_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_wordpresscomments`
--
ALTER TABLE `wp_wordpresscomments`
 ADD PRIMARY KEY (`comment_ID`), ADD KEY `comment_post_ID` (`comment_post_ID`), ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`), ADD KEY `comment_date_gmt` (`comment_date_gmt`), ADD KEY `comment_parent` (`comment_parent`), ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_wordpresslinks`
--
ALTER TABLE `wp_wordpresslinks`
 ADD PRIMARY KEY (`link_id`), ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_wordpressoptions`
--
ALTER TABLE `wp_wordpressoptions`
 ADD PRIMARY KEY (`option_id`), ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_wordpresspostmeta`
--
ALTER TABLE `wp_wordpresspostmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `post_id` (`post_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_wordpressposts`
--
ALTER TABLE `wp_wordpressposts`
 ADD PRIMARY KEY (`ID`), ADD KEY `post_name` (`post_name`(191)), ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`), ADD KEY `post_parent` (`post_parent`), ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_wordpresstermmeta`
--
ALTER TABLE `wp_wordpresstermmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `term_id` (`term_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_wordpressterms`
--
ALTER TABLE `wp_wordpressterms`
 ADD PRIMARY KEY (`term_id`), ADD KEY `slug` (`slug`(191)), ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_wordpressterm_relationships`
--
ALTER TABLE `wp_wordpressterm_relationships`
 ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`), ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_wordpressterm_taxonomy`
--
ALTER TABLE `wp_wordpressterm_taxonomy`
 ADD PRIMARY KEY (`term_taxonomy_id`), ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`), ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_wordpressusermeta`
--
ALTER TABLE `wp_wordpressusermeta`
 ADD PRIMARY KEY (`umeta_id`), ADD KEY `user_id` (`user_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_wordpressusers`
--
ALTER TABLE `wp_wordpressusers`
 ADD PRIMARY KEY (`ID`), ADD KEY `user_login_key` (`user_login`), ADD KEY `user_nicename` (`user_nicename`), ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wp_wordpresswpeditor_settings`
--
ALTER TABLE `wp_wordpresswpeditor_settings`
 ADD PRIMARY KEY (`key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_wordpresscommentmeta`
--
ALTER TABLE `wp_wordpresscommentmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_wordpresscomments`
--
ALTER TABLE `wp_wordpresscomments`
MODIFY `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `wp_wordpresslinks`
--
ALTER TABLE `wp_wordpresslinks`
MODIFY `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_wordpressoptions`
--
ALTER TABLE `wp_wordpressoptions`
MODIFY `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=266;
--
-- AUTO_INCREMENT for table `wp_wordpresspostmeta`
--
ALTER TABLE `wp_wordpresspostmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=343;
--
-- AUTO_INCREMENT for table `wp_wordpressposts`
--
ALTER TABLE `wp_wordpressposts`
MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=118;
--
-- AUTO_INCREMENT for table `wp_wordpresstermmeta`
--
ALTER TABLE `wp_wordpresstermmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_wordpressterms`
--
ALTER TABLE `wp_wordpressterms`
MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `wp_wordpressterm_taxonomy`
--
ALTER TABLE `wp_wordpressterm_taxonomy`
MODIFY `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `wp_wordpressusermeta`
--
ALTER TABLE `wp_wordpressusermeta`
MODIFY `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `wp_wordpressusers`
--
ALTER TABLE `wp_wordpressusers`
MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
